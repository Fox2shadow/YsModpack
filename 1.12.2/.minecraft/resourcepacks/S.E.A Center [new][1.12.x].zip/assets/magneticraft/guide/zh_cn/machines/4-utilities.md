# 实用设备

- [货架](utilities/1-shelving-unit.md)
- [集装箱](utilities/2-shipping-container.md)
- [无限水源方块](utilities/3-water-generator.md)
- [气锁](utilities/4-airlock.md)
- [木质饲料槽](utilities/5-feeding-trough.md)
- [铜罐](utilities/6-copper-tank.md)