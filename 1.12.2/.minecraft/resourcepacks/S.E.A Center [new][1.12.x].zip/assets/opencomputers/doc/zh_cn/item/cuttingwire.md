# 剥过的线

![Not a garrote. Honest.](oredict:oc:materialCuttingWire)

在困难合成会用到的东西,用于合成 [原始电路板](rawCircuitBoard.md). 很蛋疼
