![铁墙](block:betterwithmods:iron_wall)

铁墙一般情况下是装饰性方块,但是它可以作为[滑车](pulley.md)平台的一部分,但是需要与[滑车锚](anchor.md)连接